"""Local backend for the Surfside Grill & Pizzeria demo site.

Run with ``python main.py`` and open http://127.0.0.1:8000/.
The menu and orders are stored in surfside.db beside this file.
"""

from __future__ import annotations

import ast
from contextlib import contextmanager
import hashlib
import json
import mimetypes
import re
import secrets
import sqlite3
from datetime import date, datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit


ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "surfside.db"
HOST = "127.0.0.1"
PORT = 8000
MAX_BODY = 1_000_000
SESSIONS: dict[str, int] = {}


def password_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    rounds = 310_000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, rounds)
    return f"pbkdf2_sha256${rounds}${salt.hex()}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, rounds, salt_hex, expected = encoded.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(rounds)).hex()
        return secrets.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False

"""Open the site's SQLite database and return rows with named columns."""
def connect_db() -> sqlite3.Connection:
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db

"""Manage one database operation, saving changes or undoing them on error."""
@contextmanager
def database():
    db = connect_db()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

"""Read the original menu list from menu-data.js for the first database setup."""
def default_menu() -> list[list]:
    source = (ROOT / "menu-data.js").read_text(encoding="utf-8")
    match = re.search(r"window\.surfsideMenuItems\s*=\s*(\[.*\])\s*;?\s*$", source, re.S)
    if not match:
        raise RuntimeError("Could not read menu-data.js")
    items = ast.literal_eval(match.group(1))
    return items

"""Create the application schema and load the starter menu if needed."""
def initialize_db() -> None:
    with database() as db:
        # Preserve the original demo tables so their data can be copied into
        # the normalized schema below. Renaming is only needed on old installs.
        existing = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "menu" in existing and "legacy_menu" not in existing:
            db.execute("ALTER TABLE menu RENAME TO legacy_menu")
        if "orders" in existing and "legacy_orders" not in existing:
            columns = {row[1] for row in db.execute("PRAGMA table_info(orders)")}
            if "id" in columns and "fulfillment" in columns:
                db.execute("ALTER TABLE orders RENAME TO legacy_orders")
                if "order_items" in existing:
                    db.execute("ALTER TABLE order_items RENAME TO legacy_order_items")
        db.executescript("""
            CREATE TABLE IF NOT EXISTS roles (
                role_id INTEGER PRIMARY KEY AUTOINCREMENT,
                role_name TEXT NOT NULL UNIQUE
            );
            INSERT OR IGNORE INTO roles(role_id,role_name) VALUES
                (1,'Customer'),(2,'Employee'),(3,'Manager'),(4,'Admin');
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                role_id INTEGER NOT NULL REFERENCES roles(role_id) ON DELETE RESTRICT ON UPDATE CASCADE,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                phone_number TEXT NOT NULL,
                is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS customer_profiles (
                customer_id INTEGER PRIMARY KEY REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE,
                loyalty_points INTEGER NOT NULL DEFAULT 0,
                saved_address TEXT
            );
            CREATE TABLE IF NOT EXISTS employee_profiles (
                employee_id INTEGER PRIMARY KEY REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE,
                employee_code TEXT NOT NULL UNIQUE,
                override_pin_hash TEXT
            );
            CREATE TABLE IF NOT EXISTS menu_categories (
                category_id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_name TEXT NOT NULL UNIQUE,
                display_order INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS menu_items (
                item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_id INTEGER NOT NULL REFERENCES menu_categories(category_id) ON DELETE RESTRICT ON UPDATE CASCADE,
                item_name TEXT NOT NULL,
                description TEXT,
                price NUMERIC NOT NULL CHECK(price >= 0),
                is_available INTEGER NOT NULL DEFAULT 1 CHECK(is_available IN (0,1)),
                image_url TEXT,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS orders (
                order_id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
                employee_id INTEGER REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
                order_source TEXT NOT NULL CHECK(order_source IN ('ONLINE','PHONE','IN_PERSON')),
                order_status TEXT NOT NULL DEFAULT 'PREPARATION' CHECK(order_status IN ('PREPARATION','IN_OVEN','READY_FOR_PICKUP','COMPLETED','CANCELLED')),
                subtotal NUMERIC NOT NULL,
                tax_amount NUMERIC NOT NULL,
                total_amount NUMERIC NOT NULL,
                payment_status TEXT NOT NULL DEFAULT 'PENDING' CHECK(payment_status IN ('PENDING','PAID','REFUNDED')),
                payment_token TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS order_items (
                order_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE ON UPDATE CASCADE,
                menu_item_id INTEGER NOT NULL REFERENCES menu_items(item_id) ON DELETE RESTRICT ON UPDATE CASCADE,
                quantity INTEGER NOT NULL CHECK(quantity > 0),
                unit_price NUMERIC NOT NULL,
                special_notes TEXT
            );
            CREATE TABLE IF NOT EXISTS order_audit_logs (
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE ON UPDATE CASCADE,
                action_type TEXT NOT NULL,
                performed_by INTEGER NOT NULL REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE,
                authorized_by INTEGER REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
                notes TEXT,
                timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS daily_deals (
                deal_id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                discount_percentage NUMERIC,
                event_date TEXT NOT NULL,
                is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
                created_by INTEGER NOT NULL REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE
            );
            CREATE TABLE IF NOT EXISTS about_content (
                content_id INTEGER PRIMARY KEY AUTOINCREMENT,
                section_key TEXT NOT NULL UNIQUE,
                title TEXT NOT NULL,
                body_content TEXT NOT NULL,
                updated_by INTEGER NOT NULL REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
        """)
        # Older versions pointed audit entries at the abandoned customer_orders
        # table, which made every new normalized order fail its audit insert.
        audit_foreign_keys = db.execute("PRAGMA foreign_key_list(order_audit_logs)").fetchall()
        if any(row[2] == "customer_orders" for row in audit_foreign_keys):
            db.execute("""CREATE TABLE order_audit_logs_new (
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE ON UPDATE CASCADE,
                action_type TEXT NOT NULL,
                performed_by INTEGER NOT NULL REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE,
                authorized_by INTEGER REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
                notes TEXT,
                timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )""")
            db.execute("""INSERT INTO order_audit_logs_new(log_id,order_id,action_type,performed_by,authorized_by,notes,timestamp)
                SELECT log_id,order_id,action_type,performed_by,authorized_by,notes,timestamp FROM order_audit_logs""")
            db.execute("DROP TABLE order_audit_logs")
            db.execute("ALTER TABLE order_audit_logs_new RENAME TO order_audit_logs")
        if db.execute("SELECT COUNT(*) FROM menu_items").fetchone()[0] == 0:
            legacy_exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='legacy_menu'").fetchone()
            source = db.execute("SELECT category,name,price,description FROM legacy_menu ORDER BY position").fetchall() if legacy_exists else default_menu()
            category_ids = {}
            for position, row in enumerate(source):
                category, name, price, description = row
                if category not in category_ids:
                    db.execute("INSERT INTO menu_categories(category_name,display_order) VALUES(?,?)", (category, position))
                    category_ids[category] = db.execute("SELECT category_id FROM menu_categories WHERE category_name=?", (category,)).fetchone()[0]
                db.execute("INSERT INTO menu_items(category_id,item_name,description,price,is_available) VALUES(?,?,?,?,1)",
                           (category_ids[category], name, description, float(price)))

        # Move legacy orders forward while retaining the old identifier in the
        # audit notes. Historical email addresses become guest customer rows.
        legacy_orders = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='legacy_orders'").fetchone()
        if legacy_orders and not db.execute("SELECT 1 FROM orders LIMIT 1").fetchone():
            legacy_rows = db.execute("SELECT * FROM legacy_orders ORDER BY created_at").fetchall()
            for old in legacy_rows:
                customer = db.execute("SELECT user_id FROM users WHERE email=?", (old['email'],)).fetchone()
                if not customer:
                    guest_hash = hashlib.sha256(secrets.token_bytes(32)).hexdigest()
                    db.execute("INSERT INTO users(role_id,email,password_hash,first_name,last_name,phone_number) VALUES(1,?,?,?,?,?)",
                               (old['email'], guest_hash, 'Guest', 'Customer', ''))
                    customer_id = db.execute("SELECT user_id FROM users WHERE email=?", (old['email'],)).fetchone()[0]
                    db.execute("INSERT INTO customer_profiles(customer_id) VALUES(?)", (customer_id,))
                else:
                    customer_id = customer['user_id']
                total = round(float(old['total']), 2)
                created_at = old['created_at']
                cursor = db.execute("INSERT INTO orders(customer_id,order_source,order_status,subtotal,tax_amount,total_amount,payment_status,created_at,updated_at) VALUES(?,'ONLINE','PREPARATION',?,0,?,'PENDING',?,?)",
                                    (customer_id, total, total, created_at, created_at))
                if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='legacy_order_items'").fetchone():
                    old_items = db.execute("SELECT name,quantity,price FROM legacy_order_items WHERE order_id=?", (old['id'],)).fetchall()
                    for line in old_items:
                        menu_row = db.execute("SELECT item_id FROM menu_items WHERE item_name=? LIMIT 1", (line['name'],)).fetchone()
                        if menu_row:
                            db.execute("INSERT INTO order_items(order_id,menu_item_id,quantity,unit_price,special_notes) VALUES(?,?,?,?,?)",
                                       (cursor.lastrowid, menu_row['item_id'], line['quantity'], line['price'], None))

"""Send an API error as JSON with the supplied HTTP status and message."""
def api_error(handler: BaseHTTPRequestHandler, status: int, message: str) -> None:
    handler.send_json({"error": message}, status)

"""Handle website file requests and the menu and order API requests."""
class SurfsideHandler(BaseHTTPRequestHandler):
    server_version = "SurfsideDemo/1.0"

    """Print each request to the terminal running the server."""
    def log_message(self, format: str, *args) -> None:
        print("%s - %s" % (self.address_string(), format % args))

    """Encode a Python value as JSON and send it with response headers."""
    def send_json(self, payload, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    """Read and decode a size-limited JSON request body, rejecting invalid data."""
    def read_json(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("Invalid Content-Length")
        if length < 1 or length > MAX_BODY:
            raise ValueError("Request body is empty or too large")
        try:
            return json.loads(self.rfile.read(length))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("Request body must be valid JSON")

    def current_user(self):
        authorization = self.headers.get("Authorization", "")
        scheme, _, token = authorization.partition(" ")
        if scheme.lower() != "bearer" or not token:
            return None
        user_id = SESSIONS.get(token)
        if not user_id:
            return None
        with database() as db:
            return db.execute("""SELECT u.user_id,u.email,u.first_name,u.last_name,r.role_name
                FROM users u JOIN roles r ON r.role_id=u.role_id
                WHERE u.user_id=? AND u.is_active=1""", (user_id,)).fetchone()

    def require_roles(self, *roles):
        user = self.current_user()
        if not user:
            api_error(self, 401, "Sign in to continue")
            return None
        if user["role_name"] not in roles:
            api_error(self, 403, "Your account does not have permission for this action")
            return None
        return user

    """Serve the health check, menu, orders, or a requested site asset."""
    def do_GET(self) -> None:
        parsed = urlsplit(self.path)
        if parsed.path == "/api/health":
            self.send_json({"status": "ok"})
        elif parsed.path == "/api/me":
            user = self.current_user()
            if not user:
                api_error(self, 401, "Not signed in")
            else:
                self.send_json({"user": dict(user)})
        elif parsed.path == "/api/menu":
            manage = parse_qs(parsed.query).get("manage") == ["1"]
            if manage and not self.require_roles("Admin"):
                return
            with database() as db:
                items = db.execute(f"""SELECT c.category_name AS category,m.item_name AS name,m.price,m.description,m.is_available
                    FROM menu_items m JOIN menu_categories c ON c.category_id=m.category_id
                    {'WHERE 1=1' if manage else 'WHERE m.is_available=1'}
                    ORDER BY c.display_order,c.category_id,m.item_id""").fetchall()
            self.send_json({"items": [list(row)[:4] + [bool(row[4])] if manage else list(row)[:4] for row in items]})
        elif parsed.path == "/api/orders":
            user = self.require_roles("Customer", "Employee", "Admin")
            if user:
                self.get_orders(user)
        elif parsed.path == "/api/deals":
            self.get_deals(parse_qs(parsed.query))
        elif parsed.path == "/api/about":
            with database() as db:
                rows = db.execute("SELECT section_key,title,body_content,updated_at FROM about_content ORDER BY content_id").fetchall()
            self.send_json({"sections": [dict(row) for row in rows]})
        elif parsed.path.startswith("/api/"):
            api_error(self, 404, "API route not found")
        else:
            self.serve_file(parsed.path)

    """Validate and replace the shared menu sent to the menu API."""
    def do_PUT(self) -> None:
        path = urlsplit(self.path).path
        order_match = re.fullmatch(r"/api/orders/(\d+)", path)
        if order_match:
            self.update_order(int(order_match.group(1)))
            return
        if path != "/api/menu":
            api_error(self, 404, "API route not found")
            return
        if not self.require_roles("Admin"):
            return
        try:
            payload = self.read_json()
            items = payload.get("items") if isinstance(payload, dict) else None
            if not isinstance(items, list) or len(items) > 500:
                raise ValueError("Menu must contain a list of up to 500 items")
            clean = []
            names = set()
            for item in items:
                if not isinstance(item, list) or len(item) not in (4, 5):
                    raise ValueError("Each menu item needs category, name, price, and description")
                category, name, price, description = item[:4]
                is_available = item[4] if len(item) == 5 else True
                if not all(isinstance(v, str) for v in (category, name, description)):
                    raise ValueError("Menu text fields must be strings")
                if not isinstance(is_available, bool):
                    raise ValueError("Menu availability must be true or false")
                name = name.strip()
                try:
                    price = float(price)
                except (TypeError, ValueError):
                    raise ValueError("Menu prices must be numbers")
                if not category.strip() or not name or len(name) > 80 or len(description) > 240:
                    raise ValueError("Menu category, name, or description is invalid")
                if price < 0 or price > 10000:
                    raise ValueError("Menu price must be between 0 and 10000")
                if name.casefold() in names:
                    raise ValueError("Menu item names must be unique")
                names.add(name.casefold())
                clean.append((category.strip(), name, round(price, 2), description.strip(), is_available))
            with database() as db:
                db.execute("UPDATE menu_items SET is_available=0")
                category_ids = {}
                for position, (category, name, price, description, is_available) in enumerate(clean):
                    if category not in category_ids:
                        db.execute("INSERT OR IGNORE INTO menu_categories(category_name,display_order) VALUES(?,?)", (category, position))
                        category_ids[category] = db.execute("SELECT category_id FROM menu_categories WHERE category_name=?", (category,)).fetchone()[0]
                        db.execute("UPDATE menu_categories SET display_order=? WHERE category_id=?", (position, category_ids[category]))
                    existing = db.execute("SELECT item_id FROM menu_items WHERE item_name=? AND category_id=?", (name, category_ids[category])).fetchone()
                    if existing:
                        db.execute("UPDATE menu_items SET description=?,price=?,is_available=?,updated_at=CURRENT_TIMESTAMP WHERE item_id=?",
                                   (description, price, int(is_available), existing['item_id']))
                    else:
                        db.execute("INSERT INTO menu_items(category_id,item_name,description,price,is_available) VALUES(?,?,?,?,?)",
                                   (category_ids[category], name, description, price, int(is_available)))
            self.send_json({"items": [list(row) for row in clean]})
        except ValueError as error:
            api_error(self, 400, str(error))
        except sqlite3.IntegrityError:
            api_error(self, 400, "Menu item names must be unique")

    def update_order(self, order_id: int) -> None:
        user = self.require_roles("Admin")
        if not user:
            return
        try:
            payload = self.read_json()
            if not isinstance(payload, dict):
                raise ValueError("Order update must be a JSON object")
            raw_items = payload.get("items")
            fulfillment = payload.get("mode")
            address = str(payload.get("address", "")).strip()
            unit = str(payload.get("unit", "")).strip()
            if fulfillment not in ("delivery", "pickup"):
                raise ValueError("Choose delivery or pickup")
            if fulfillment == "delivery" and (not address or len(address) > 300):
                raise ValueError("A valid delivery address is required")
            if len(unit) > 100 or not isinstance(raw_items, list) or not raw_items or len(raw_items) > 100:
                raise ValueError("Order needs between 1 and 100 item types")
            clean = []
            names = set()
            for item in raw_items:
                if not isinstance(item, dict) or not isinstance(item.get("name"), str):
                    raise ValueError("Each order item needs a name and quantity")
                name = item["name"].strip()
                quantity = item.get("quantity")
                notes = item.get("special_notes", "")
                if not name or isinstance(quantity, bool) or not isinstance(quantity, int) or not 1 <= quantity <= 99:
                    raise ValueError("Item name or quantity is invalid")
                if not isinstance(notes, str) or len(notes) > 500:
                    raise ValueError("Item notes must be text up to 500 characters")
                if name.casefold() in names:
                    raise ValueError("Each menu item can appear only once")
                names.add(name.casefold())
                clean.append((name, quantity, notes.strip()))
            with database() as db:
                order = db.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
                if not order:
                    api_error(self, 404, "Order not found")
                    return
                if order["order_status"] in ("COMPLETED", "CANCELLED"):
                    api_error(self, 409, "Closed orders cannot be edited")
                    return
                menu = {}
                for name, _, _ in clean:
                    item = db.execute("SELECT item_id,price FROM menu_items WHERE item_name=? COLLATE NOCASE", (name,)).fetchone()
                    if not item:
                        raise ValueError(f"{name} is no longer on the menu")
                    menu[name] = item
                priced = [{"name": name, "quantity": quantity, "price": menu[name]["price"], "menu_item_id": menu[name]["item_id"], "special_notes": notes}
                          for name, quantity, notes in clean]
                subtotal = round(sum(row["price"] * row["quantity"] for row in priced), 2)
                total = round(subtotal + float(order["tax_amount"]), 2)
                db.execute("DELETE FROM order_items WHERE order_id=?", (order_id,))
                db.executemany("INSERT INTO order_items(order_id,menu_item_id,quantity,unit_price,special_notes) VALUES(?,?,?,?,?)",
                               [(order_id, row["menu_item_id"], row["quantity"], row["price"], row["special_notes"] or None) for row in priced])
                db.execute("UPDATE orders SET subtotal=?,total_amount=?,updated_at=CURRENT_TIMESTAMP WHERE order_id=?", (subtotal, total, order_id))
                audit = db.execute("SELECT log_id,notes FROM order_audit_logs WHERE order_id=? AND action_type='ORDER_PLACED' ORDER BY log_id LIMIT 1", (order_id,)).fetchone()
                metadata = {}
                if audit and audit["notes"]:
                    try:
                        metadata = json.loads(audit["notes"])
                    except json.JSONDecodeError:
                        metadata = {}
                metadata.update({"fulfillment": fulfillment, "address": address, "unit": unit})
                if audit:
                    db.execute("UPDATE order_audit_logs SET notes=? WHERE log_id=?", (json.dumps(metadata), audit["log_id"]))
                db.execute("INSERT INTO order_audit_logs(order_id,action_type,performed_by,notes) VALUES(?,'ORDER_EDITED',?,?)",
                           (order_id, user["user_id"], "Updated by administrator"))
            self.send_json({"id": f"SS-{order_id}", "total": total,
                            "items": [{key: row[key] for key in ("name", "quantity", "price", "special_notes")} for row in priced]})
        except ValueError as error:
            api_error(self, 400, str(error))
        except sqlite3.Error:
            api_error(self, 500, "The order could not be updated")

    """Validate a checkout request, calculate prices, and save its order."""
    def do_POST(self) -> None:
        path = urlsplit(self.path).path
        if path == "/api/auth/register":
            self.register_customer()
            return
        if path == "/api/auth/login":
            self.login()
            return
        if path == "/api/auth/logout":
            authorization = self.headers.get("Authorization", "")
            _, _, token = authorization.partition(" ")
            SESSIONS.pop(token, None)
            self.send_json({"ok": True})
            return
        if path != "/api/orders":
            api_error(self, 404, "API route not found")
            return
        user = self.require_roles("Customer")
        if not user:
            return
        try:
            payload = self.read_json()
            if not isinstance(payload, dict):
                raise ValueError("Order must be a JSON object")
            fulfillment = payload.get("mode")
            address = str(payload.get("address", "")).strip()
            unit = str(payload.get("unit", "")).strip()
            raw_items = payload.get("items")
            if fulfillment not in ("delivery", "pickup"):
                raise ValueError("Choose delivery or pickup")
            if fulfillment == "delivery" and (not address or len(address) > 300):
                raise ValueError("A valid delivery address is required")
            if not isinstance(raw_items, list) or not raw_items or len(raw_items) > 100:
                raise ValueError("Order must contain between 1 and 100 item types")
            quantities = {}
            for item in raw_items:
                if not isinstance(item, dict) or not isinstance(item.get("name"), str):
                    raise ValueError("Order items need a name and quantity")
                name, quantity = item["name"].strip(), item.get("quantity")
                if not name or isinstance(quantity, bool) or not isinstance(quantity, int) or quantity < 1 or quantity > 99:
                    raise ValueError("Item name or quantity is invalid")
                quantities[name] = quantities.get(name, 0) + quantity
                if quantities[name] > 99:
                    raise ValueError("Maximum quantity per item is 99")
            with database() as db:
                menu = {row["name"]: dict(row) for row in db.execute("""SELECT m.item_id,m.item_name AS name,m.price
                    FROM menu_items m WHERE m.is_available=1""")}
                if any(name not in menu for name in quantities):
                    raise ValueError("One or more ordered items are no longer on the menu")
                items = [{"name": name, "quantity": qty, "price": menu[name]} for name, qty in quantities.items()]
                for item in items:
                    item["price"] = menu[item["name"]]["price"]
                    item["menu_item_id"] = menu[item["name"]]["item_id"]
                subtotal = round(sum(item["price"] * item["quantity"] for item in items), 2)
                customer_id = user['user_id']
                db.execute("INSERT OR IGNORE INTO customer_profiles(customer_id) VALUES(?)", (customer_id,))
                if address:
                    db.execute("UPDATE customer_profiles SET saved_address=? WHERE customer_id=?", (address, customer_id))
                created_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
                cursor = db.execute("INSERT INTO orders(customer_id,order_source,order_status,subtotal,tax_amount,total_amount,payment_status,created_at,updated_at) VALUES(?,'ONLINE','PREPARATION',?,0,?,'PENDING',?,?)",
                                    (customer_id, subtotal, subtotal, created_at, created_at))
                order_id = cursor.lastrowid
                db.executemany("INSERT INTO order_items(order_id,menu_item_id,quantity,unit_price,special_notes) VALUES(?,?,?,?,?)",
                               [(order_id, item['menu_item_id'], item['quantity'], item['price'], None) for item in items])
                notes = json.dumps({"email": user['email'], "fulfillment": fulfillment, "address": address, "unit": unit})
                db.execute("INSERT INTO order_audit_logs(order_id,action_type,performed_by,notes) VALUES(?,'ORDER_PLACED',?,?)",
                           (order_id, customer_id, notes))
                total = subtotal
                order_id = f"SS-{order_id}"
            self.send_json({"id": order_id, "date": created_at, "mode": fulfillment, "items": [{k:v for k,v in item.items() if k in ('name','quantity','price')} for item in items], "total": total}, 201)
        except ValueError as error:
            api_error(self, 400, str(error))
        except sqlite3.Error:
            api_error(self, 500, "The order could not be saved")

    def do_PATCH(self) -> None:
        match = re.fullmatch(r"/api/orders/(\d+)/status", urlsplit(self.path).path)
        if not match:
            api_error(self, 404, "API route not found")
            return
        user = self.require_roles("Employee", "Admin")
        if not user:
            return
        try:
            payload = self.read_json()
            status = payload.get("status") if isinstance(payload, dict) else None
            allowed = {"IN_OVEN", "COMPLETED"}
            if user["role_name"] == "Admin":
                allowed.add("CANCELLED")
            if status not in allowed:
                raise ValueError("Choose a status permitted for your role")
            order_id = int(match.group(1))
            with database() as db:
                order = db.execute("SELECT order_id,order_status FROM orders WHERE order_id=?", (order_id,)).fetchone()
                if not order:
                    api_error(self, 404, "Order not found")
                    return
                if order['order_status'] in ('COMPLETED', 'CANCELLED'):
                    api_error(self, 409, "This order is already closed")
                    return
                db.execute("UPDATE orders SET order_status=?,updated_at=CURRENT_TIMESTAMP WHERE order_id=?", (status, order_id))
                db.execute("INSERT INTO order_audit_logs(order_id,action_type,performed_by,notes) VALUES(?,?,?,?)",
                           (order_id, "STATUS_CHANGED", user["user_id"], status))
            self.send_json({"orderId": f"SS-{order_id}", "status": status})
        except ValueError as error:
            api_error(self, 400, str(error))

    def register_customer(self) -> None:
        try:
            payload = self.read_json()
            if not isinstance(payload, dict):
                raise ValueError("Account details must be a JSON object")
            email = str(payload.get("email", "")).strip().lower()
            password = payload.get("password")
            first = str(payload.get("first_name", "")).strip()
            last = str(payload.get("last_name", "")).strip()
            phone = str(payload.get("phone_number", "")).strip()
            if len(email) > 254 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
                raise ValueError("Enter a valid email address")
            if not isinstance(password, str) or len(password) < 8 or len(password) > 200:
                raise ValueError("Password must be between 8 and 200 characters")
            if not first or len(first) > 100 or not last or len(last) > 100 or not phone or len(phone) > 20:
                raise ValueError("Enter your first name, last name, and phone number")
            with database() as db:
                existing = db.execute("SELECT user_id,first_name,last_name,password_hash FROM users WHERE email=? COLLATE NOCASE", (email,)).fetchone()
                if existing:
                    # Older guest checkouts reserved email addresses without
                    # passwords; let the owner claim that history on signup.
                    if existing['first_name'] != 'Guest' or existing['last_name'] != 'Customer' or existing['password_hash'].startswith('pbkdf2_sha256$'):
                        raise sqlite3.IntegrityError("An account with this email already exists")
                    user_id = existing['user_id']
                    db.execute("UPDATE users SET password_hash=?,first_name=?,last_name=?,phone_number=? WHERE user_id=?",
                               (password_hash(password), first, last, phone, user_id))
                else:
                    db.execute("INSERT INTO users(role_id,email,password_hash,first_name,last_name,phone_number) VALUES(1,?,?,?,?,?)",
                               (email, password_hash(password), first, last, phone))
                    user_id = db.execute("SELECT user_id FROM users WHERE email=? COLLATE NOCASE", (email,)).fetchone()[0]
                db.execute("INSERT OR IGNORE INTO customer_profiles(customer_id) VALUES(?)", (user_id,))
            self.create_session(user_id)
        except ValueError as error:
            api_error(self, 400, str(error))
        except sqlite3.IntegrityError:
            api_error(self, 409, "An account with this email already exists")

    def login(self) -> None:
        try:
            payload = self.read_json()
            if not isinstance(payload, dict):
                raise ValueError("Sign-in details must be a JSON object")
            email = str(payload.get("email", "")).strip().lower()
            if email == "test":
                email = "test@example.com"
            password = payload.get("password")
            with database() as db:
                user = db.execute("SELECT user_id,password_hash,is_active FROM users WHERE email=? COLLATE NOCASE", (email,)).fetchone()
            if not user or not user["is_active"] or not isinstance(password, str) or not verify_password(password, user["password_hash"]):
                api_error(self, 401, "Email or password is incorrect")
                return
            self.create_session(user["user_id"])
        except ValueError as error:
            api_error(self, 400, str(error))

    def create_session(self, user_id: int) -> None:
        token = secrets.token_urlsafe(32)
        SESSIONS[token] = user_id
        with database() as db:
            user = db.execute("""SELECT u.user_id,u.email,u.first_name,u.last_name,r.role_name
                FROM users u JOIN roles r ON r.role_id=u.role_id WHERE u.user_id=?""", (user_id,)).fetchone()
        self.send_json({"token": token, "user": dict(user)})

    """Return a customer's own orders or the complete staff order list."""
    def get_orders(self, user) -> None:
        with database() as db:
            if user['role_name'] == 'Customer':
                rows = db.execute("SELECT o.*,u.email FROM orders o LEFT JOIN users u ON u.user_id=o.customer_id WHERE o.customer_id=? ORDER BY o.created_at DESC", (user['user_id'],)).fetchall()
            else:
                rows = db.execute("SELECT o.*,u.email FROM orders o LEFT JOIN users u ON u.user_id=o.customer_id ORDER BY o.created_at DESC").fetchall()
            orders = []
            for row in rows:
                items = db.execute("""SELECT m.item_name AS name,oi.quantity,oi.unit_price AS price,oi.special_notes
                    FROM order_items oi JOIN menu_items m ON m.item_id=oi.menu_item_id WHERE oi.order_id=?""",
                                   (row["order_id"],)).fetchall()
                audit = db.execute("SELECT notes FROM order_audit_logs WHERE order_id=? AND action_type='ORDER_PLACED' ORDER BY log_id LIMIT 1",
                                   (row['order_id'],)).fetchone()
                try:
                    metadata = json.loads(audit['notes']) if audit and audit['notes'] else {}
                except (TypeError, json.JSONDecodeError):
                    metadata = {}
                status = {'PREPARATION':'Received','IN_OVEN':'In progress','READY_FOR_PICKUP':'Ready','COMPLETED':'Completed','CANCELLED':'Cancelled'}.get(row['order_status'], row['order_status'])
                orders.append({
                    "id": f"SS-{row['order_id']}", "orderId": row['order_id'], "email": row['email'], "date": row["created_at"], "createdAt": row["created_at"],
                    "mode": metadata.get('fulfillment', 'pickup'), "fulfillment": metadata.get('fulfillment', 'pickup'),
                    "address": metadata.get('address', ''), "unit": metadata.get('unit', ''),
                    "items": [dict(item) for item in items], "total": row["total_amount"], "status": status,
                })
        self.send_json({"orders": orders, "role": user['role_name']})

    """Return active deals assigned to the requested date (today by default)."""
    def get_deals(self, query) -> None:
        requested = query.get("date", [date.today().isoformat()])[0]
        try:
            assigned_date = date.fromisoformat(requested).isoformat()
        except (TypeError, ValueError):
            api_error(self, 400, "Date must use YYYY-MM-DD format")
            return
        with database() as db:
            rows = db.execute("""SELECT deal_id,title,description,discount_percentage,event_date,is_active
                FROM daily_deals WHERE is_active=1 AND event_date=? ORDER BY deal_id""", (assigned_date,)).fetchall()
        self.send_json({"date": assigned_date, "deals": [dict(row) for row in rows]})

    """Serve an allowed site file while blocking access outside the site folder."""
    def serve_file(self, raw_path: str) -> None:
        relative = unquote(raw_path).lstrip("/") or "index.html"
        target = (ROOT / relative).resolve()
        try:
            target.relative_to(ROOT)
        except ValueError:
            self.send_error(403, "Forbidden")
            return
        if target.parent != ROOT or target.suffix.lower() not in {".html", ".js", ".png", ".jpg", ".jpeg", ".css", ".ico"}:
            self.send_error(404, "File not found")
            return
        if not target.is_file():
            self.send_error(404, "File not found")
            return
        content = target.read_bytes()
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in ("application/javascript", "application/json"):
            content_type += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(content)

"""Prepare the database and run the local website server until stopped."""
def main() -> None:
    initialize_db()
    server = ThreadingHTTPServer((HOST, PORT), SurfsideHandler)
    print(f"Surfside site running at http://{HOST}:{PORT}/ (Ctrl+C to stop)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping Surfside server…")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
