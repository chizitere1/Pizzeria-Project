"""Local backend for the Surfside Grill & Pizzeria demo site.

Run with ``python main.py`` and open http://127.0.0.1:8000/.
The menu and orders are stored in surfside.db beside this file.
"""

from __future__ import annotations

import ast
from contextlib import contextmanager
import json
import mimetypes
import re
import sqlite3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit
import uuid


ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "surfside.db"
HOST = "127.0.0.1"
PORT = 8000
MAX_BODY = 1_000_000

"""Open the site's SQLite database and return rows with named columns."""
def connect_db() -> sqlite3.Connection:
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db

"""Manage one database operation, saving changes or undoing them on error."""
@contextmanager
def database():
    db = connect_db()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

"""Read the original menu list from menu-data.js for the first database setup."""
def default_menu() -> list[list]:
    source = (ROOT / "menu-data.js").read_text(encoding="utf-8")
    match = re.search(r"window\.surfsideMenuItems\s*=\s*(\[.*\])\s*;?\s*$", source, re.S)
    if not match:
        raise RuntimeError("Could not read menu-data.js")
    items = ast.literal_eval(match.group(1))
    return items

"""Create the menu and order tables, then load the starter menu if needed."""
def initialize_db() -> None:
    with database() as db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS menu (
                position INTEGER PRIMARY KEY,
                category TEXT NOT NULL,
                name TEXT NOT NULL UNIQUE,
                price REAL NOT NULL CHECK(price >= 0),
                description TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS orders (
                id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                fulfillment TEXT NOT NULL CHECK(fulfillment IN ('delivery','pickup')),
                email TEXT NOT NULL,
                address TEXT NOT NULL DEFAULT '',
                unit TEXT NOT NULL DEFAULT '',
                total REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'Received'
            );
            CREATE TABLE IF NOT EXISTS order_items (
                order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                quantity INTEGER NOT NULL CHECK(quantity > 0),
                price REAL NOT NULL CHECK(price >= 0)
            );
        """)
        if db.execute("SELECT COUNT(*) FROM menu").fetchone()[0] == 0:
            db.executemany(
                "INSERT INTO menu(position,category,name,price,description) VALUES(?,?,?,?,?)",
                [(i, str(row[0]), str(row[1]), float(row[2]), str(row[3])) for i, row in enumerate(default_menu())],
            )

"""Send an API error as JSON with the supplied HTTP status and message."""
def api_error(handler: BaseHTTPRequestHandler, status: int, message: str) -> None:
    handler.send_json({"error": message}, status)

"""Handle website file requests and the menu and order API requests."""
class SurfsideHandler(BaseHTTPRequestHandler):
    server_version = "SurfsideDemo/1.0"

    """Print each request to the terminal running the server."""
    def log_message(self, format: str, *args) -> None:
        print("%s - %s" % (self.address_string(), format % args))

    """Encode a Python value as JSON and send it with response headers."""
    def send_json(self, payload, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    """Read and decode a size-limited JSON request body, rejecting invalid data."""
    def read_json(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("Invalid Content-Length")
        if length < 1 or length > MAX_BODY:
            raise ValueError("Request body is empty or too large")
        try:
            return json.loads(self.rfile.read(length))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("Request body must be valid JSON")

    """Serve the health check, menu, orders, or a requested site asset."""
    def do_GET(self) -> None:
        parsed = urlsplit(self.path)
        if parsed.path == "/api/health":
            self.send_json({"status": "ok"})
        elif parsed.path == "/api/menu":
            with database() as db:
                items = db.execute("SELECT category,name,price,description FROM menu ORDER BY position").fetchall()
            self.send_json({"items": [list(row) for row in items]})
        elif parsed.path == "/api/orders":
            self.get_orders(parse_qs(parsed.query))
        elif parsed.path.startswith("/api/"):
            api_error(self, 404, "API route not found")
        else:
            self.serve_file(parsed.path)

    """Validate and replace the shared menu sent to the menu API."""
    def do_PUT(self) -> None:
        if urlsplit(self.path).path != "/api/menu":
            api_error(self, 404, "API route not found")
            return
        try:
            payload = self.read_json()
            items = payload.get("items") if isinstance(payload, dict) else None
            if not isinstance(items, list) or len(items) > 500:
                raise ValueError("Menu must contain a list of up to 500 items")
            clean = []
            names = set()
            for item in items:
                if not isinstance(item, list) or len(item) != 4:
                    raise ValueError("Each menu item needs category, name, price, and description")
                category, name, price, description = item
                if not all(isinstance(v, str) for v in (category, name, description)):
                    raise ValueError("Menu text fields must be strings")
                name = name.strip()
                try:
                    price = float(price)
                except (TypeError, ValueError):
                    raise ValueError("Menu prices must be numbers")
                if not category.strip() or not name or len(name) > 80 or len(description) > 240:
                    raise ValueError("Menu category, name, or description is invalid")
                if price < 0 or price > 10000:
                    raise ValueError("Menu price must be between 0 and 10000")
                if name.casefold() in names:
                    raise ValueError("Menu item names must be unique")
                names.add(name.casefold())
                clean.append((category.strip(), name, round(price, 2), description.strip()))
            with database() as db:
                db.execute("DELETE FROM menu")
                db.executemany(
                    "INSERT INTO menu(position,category,name,price,description) VALUES(?,?,?,?,?)",
                    [(i, *item) for i, item in enumerate(clean)],
                )
            self.send_json({"items": [list(row) for row in clean]})
        except ValueError as error:
            api_error(self, 400, str(error))
        except sqlite3.IntegrityError:
            api_error(self, 400, "Menu item names must be unique")

    """Validate a checkout request, calculate prices, and save its order."""
    def do_POST(self) -> None:
        if urlsplit(self.path).path != "/api/orders":
            api_error(self, 404, "API route not found")
            return
        try:
            payload = self.read_json()
            if not isinstance(payload, dict):
                raise ValueError("Order must be a JSON object")
            fulfillment = payload.get("mode")
            email = str(payload.get("email", "")).strip().lower()
            address = str(payload.get("address", "")).strip()
            unit = str(payload.get("unit", "")).strip()
            raw_items = payload.get("items")
            if fulfillment not in ("delivery", "pickup"):
                raise ValueError("Choose delivery or pickup")
            if len(email) > 254 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
                raise ValueError("Enter a valid email address")
            if fulfillment == "delivery" and (not address or len(address) > 300):
                raise ValueError("A valid delivery address is required")
            if not isinstance(raw_items, list) or not raw_items or len(raw_items) > 100:
                raise ValueError("Order must contain between 1 and 100 item types")
            quantities = {}
            for item in raw_items:
                if not isinstance(item, dict) or not isinstance(item.get("name"), str):
                    raise ValueError("Order items need a name and quantity")
                name, quantity = item["name"].strip(), item.get("quantity")
                if not name or isinstance(quantity, bool) or not isinstance(quantity, int) or quantity < 1 or quantity > 99:
                    raise ValueError("Item name or quantity is invalid")
                quantities[name] = quantities.get(name, 0) + quantity
                if quantities[name] > 99:
                    raise ValueError("Maximum quantity per item is 99")
            with database() as db:
                menu = {row["name"]: row["price"] for row in db.execute("SELECT name,price FROM menu")}
                if any(name not in menu for name in quantities):
                    raise ValueError("One or more ordered items are no longer on the menu")
                items = [{"name": name, "quantity": qty, "price": menu[name]} for name, qty in quantities.items()]
                total = round(sum(item["price"] * item["quantity"] for item in items), 2)
                order_id = "SS-" + uuid.uuid4().hex[:8].upper()
                created_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
                db.execute(
                    "INSERT INTO orders(id,created_at,fulfillment,email,address,unit,total) VALUES(?,?,?,?,?,?,?)",
                    (order_id, created_at, fulfillment, email, address, unit, total),
                )
                db.executemany(
                    "INSERT INTO order_items(order_id,name,quantity,price) VALUES(?,?,?,?)",
                    [(order_id, item["name"], item["quantity"], item["price"]) for item in items],
                )
            self.send_json({"id": order_id, "date": created_at, "mode": fulfillment, "items": items, "total": total}, 201)
        except ValueError as error:
            api_error(self, 400, str(error))
        except sqlite3.Error:
            api_error(self, 500, "The order could not be saved")

    """Return saved orders, optionally showing only orders for one email."""
    def get_orders(self, query) -> None:
        email_values = query.get("email")
        with database() as db:
            if email_values:
                email = email_values[0].strip().lower()
                rows = db.execute("SELECT * FROM orders WHERE email=? ORDER BY created_at DESC", (email,)).fetchall()
            else:
                rows = db.execute("SELECT * FROM orders ORDER BY created_at DESC").fetchall()
            orders = []
            for row in rows:
                items = db.execute("SELECT name,quantity,price FROM order_items WHERE order_id=?", (row["id"],)).fetchall()
                orders.append({
                    "id": row["id"], "date": row["created_at"], "createdAt": row["created_at"],
                    "mode": row["fulfillment"], "fulfillment": row["fulfillment"],
                    "items": [dict(item) for item in items], "total": row["total"], "status": row["status"],
                })
        self.send_json({"orders": orders})

    """Serve an allowed site file while blocking access outside the site folder."""
    def serve_file(self, raw_path: str) -> None:
        relative = unquote(raw_path).lstrip("/") or "index.html"
        target = (ROOT / relative).resolve()
        try:
            target.relative_to(ROOT)
        except ValueError:
            self.send_error(403, "Forbidden")
            return
        if target.parent != ROOT or target.suffix.lower() not in {".html", ".js", ".png", ".jpg", ".jpeg", ".css", ".ico"}:
            self.send_error(404, "File not found")
            return
        if not target.is_file():
            self.send_error(404, "File not found")
            return
        content = target.read_bytes()
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in ("application/javascript", "application/json"):
            content_type += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(content)

"""Prepare the database and run the local website server until stopped."""
def main() -> None:
    initialize_db()
    server = ThreadingHTTPServer((HOST, PORT), SurfsideHandler)
    print(f"Surfside site running at http://{HOST}:{PORT}/ (Ctrl+C to stop)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping Surfside server…")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
