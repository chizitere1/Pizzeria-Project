"""Create an employee or admin account for the local Surfside site.

Run ``python provision_user.py`` from the project directory. Customer accounts
are created through signin.html; elevated roles are intentionally provisioned
locally rather than offered in public registration.
"""

from __future__ import annotations

from getpass import getpass
import re

import main


def main_cli() -> None:
    main.initialize_db()
    role = input("Role (employee/admin): ").strip().lower()
    if role not in {"employee", "admin"}:
        raise SystemExit("Choose employee or admin.")
    email = input("Email: ").strip().lower()
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        raise SystemExit("Enter a valid email address.")
    first = input("First name: ").strip()
    last = input("Last name: ").strip()
    phone = input("Phone number: ").strip()
    if not first or not last or not phone:
        raise SystemExit("First name, last name, and phone number are required.")
    password = getpass("Password (8+ characters): ")
    if len(password) < 8:
        raise SystemExit("Password must be at least 8 characters.")
    employee_code = input("Employee code: ").strip() if role == "employee" else None
    if role == "employee" and not employee_code:
        raise SystemExit("Employee code is required.")
    role_id = 2 if role == "employee" else 4
    try:
        with main.database() as db:
            db.execute(
                "INSERT INTO users(role_id,email,password_hash,first_name,last_name,phone_number) VALUES(?,?,?,?,?,?)",
                (role_id, email, main.password_hash(password), first, last, phone),
            )
            user_id = db.execute("SELECT user_id FROM users WHERE email=?", (email,)).fetchone()[0]
            if role == "employee":
                db.execute("INSERT INTO employee_profiles(employee_id,employee_code) VALUES(?,?)", (user_id, employee_code))
    except Exception as error:
        raise SystemExit(f"Account was not created: {error}") from error
    print(f"Created {role} account for {email}.")


if __name__ == "__main__":
    main_cli()
